#include<iostream>
using namespace std;

#pragma pack(1)
////////////////////////////////////////////////////////////////
// Structure for Singly Linear and Singly Circular and Stack and Queue
template <class T>
struct nodeS
{
    T data;
    struct nodeS *next;
};

////////////////////////////////////////////////////////////////
// Structure for Doubly Linear and doubly Circular
template <class T>
struct nodeD
{
    T data;
    struct nodeD *next;
    struct nodeD *prev;
};

////////////////////////////////////////////////////////////////

// Class of Singly Linear Linked List

template <class T>
class SinglyLL
{
    public:
        struct nodeS<T> * First;
        int iCount;

        SinglyLL();
        void InsertFirst(T no);
        void InsertLast(T no);
        void InsertAtPos(T no,int ipos);
        void DeleteFirst();
        void DeleteLast();
        void DeleteAtPos(int ipos);
        void Display();
        // int Count();
};

template <class T>
SinglyLL<T> :: SinglyLL()
{
    First = NULL;
    iCount = 0;
}

template <class T>
void SinglyLL<T> :: InsertFirst(T no)
{
    struct nodeS<T> * newn = new struct nodeS<T>;  

    newn -> data = no;
    newn->next = NULL;

    if(First == NULL)
    {
        First = newn;
        iCount++;
    }
    else
    {
        newn->next = First;
        First = newn;
        iCount++;
    }
}

template<class T>
void SinglyLL<T>:: InsertLast(T no)
{

    struct nodeS<T>* newn = new struct nodeS<T>;

    newn->data = no;
    newn->next =  NULL;

    if(First == NULL)   
    {
        First = newn;
        iCount++;
    }
    else   
    {
        struct nodeS<T>* temp = First;

        while(temp->next != NULL)
        {
            temp = temp -> next;
        }
        temp->next = newn;
        iCount++;
    }
}
template<class T>
void SinglyLL<T> :: InsertAtPos(T no, int ipos)
{
    if((ipos < 1) || (ipos > iCount+1))
    {
        cout<<"Invalid position"<<"\n";
        return;
    }

    if(ipos == 1)
    {
        InsertFirst(no);
    }
    else if(ipos == iCount + 1)
    {
        InsertLast(no);
    }
    else
    {
        struct nodeS<T>* newn = new struct nodeS<T>;

        newn->data = no;
        newn->next = NULL;

        struct nodeS <T>* temp = First;
        for(int iCnt = 1; iCnt < ipos-1; iCnt++)
        {
            temp = temp->next;
        }

        newn->next = temp->next;
        temp->next = newn;
        iCount++;

    }
}
template<class T>
void SinglyLL<T> ::DeleteFirst()
{
    if (First == NULL) 
    {
        return;
    }
    else if (First->next == NULL) 
    {
        delete First;
        First = NULL;
        iCount--;
    }
    else
    {
        struct nodeS<T>* temp = First;
        First = First->next;
        delete temp;
        iCount--;
    }
}
template<class T>
void SinglyLL<T>:: DeleteLast()
{    
    if(First == NULL)  
    {
        return;
    }
    else if(First -> next == NULL) 
    {
        delete First;
        First = NULL;
        iCount--;
    }
    else
    {
        struct nodeS<T>* temp = First;

        while(temp->next->next != NULL)
        {
            temp = temp->next;
        }

        delete temp->next;
        temp->next = NULL;
        iCount--;

    }
}
template<class T>
void SinglyLL<T> :: DeleteAtPos(int ipos)
{
    if((ipos < 1) || (ipos > iCount))
    {
        cout<<"Invalid position"<<"\n";
        return;
    }

    if(ipos == 1)
    {
        DeleteFirst();
    }
    else if(ipos == iCount)
    {
        DeleteLast();
    }
    else
    {
        struct nodeS<T>* temp1 = First;

        for(int iCnt = 1; iCnt < ipos-1; iCnt++)
        {
            temp1 = temp1->next;
        }

        struct nodeS<T>* temp2 = temp1->next;

        temp1->next = temp2->next;
        delete temp2;

        iCount--;
    }
}

template <class T>
void SinglyLL<T> :: Display()
{
    struct nodeS<T> * temp = First;

    while(temp != NULL)
    {
        cout<<"| "<<temp->data<<" |->";
        temp = temp -> next;
    }
    cout<<"\n";
}

// template <class T>
// int SinglyLL<T> :: Count()
// {
//     struct nodeS<T> *  temp = First;
//     int iCnt = 0;

//     while(temp != NULL)
//     {
//         iCnt++;
//         temp = temp -> next;
//     }
//     return iCnt;
// }

////////////////////////////////////////////////////////////////

//  Class of Singly Circular Linked List

template <class T>
class SinglyCL
{
    public:
        struct nodeS<T> * First;
        struct nodeS<T> *Last;

        SinglyCL();

        void InsertFirst(T no);
        void InsertLast(T no);
        void InsertAtPos(T no, int iPos);

        void DeleteFirst();
        void DeleteLast();
        void DeleteAtPos(int iPos);

        void Display();
        int Count();
};

template <class T>
SinglyCL<T>::SinglyCL()
{
    First = NULL;
    Last = NULL;
}
template <class T>
void SinglyCL<T>::InsertFirst(T no)
{
    struct nodeS<T>* newn = new struct nodeS<T>;

    newn->data = no;
    newn->next = NULL;

    if((First == NULL) && (Last == NULL))    
    {
        First = Last = newn;
        (Last)->next = First;
    }
    else   
    {
        newn->next = First;
        First = newn;
        (Last)->next = First;
    }
}
template <class T>
void SinglyCL<T>::InsertLast(T no)
{
    struct nodeS <T>* newn = new struct nodeS<T>;

    newn->data = no;
    newn->next = NULL;

    if((First == NULL) && (Last == NULL))   
    {
        First = Last = newn;
        (Last)->next = First;
    }
    else    
    {
        (Last) -> next = newn;
        Last = newn;
        (Last)->next = First;
    }
}
template <class T>
void SinglyCL<T>::Display()
{
    struct nodeS<T>* temp = First;

    cout<<"Elements of Linked list are : "<<"\n";

    do
    {
        cout<<"| "<<temp->data<<" |-> ";
        temp = temp -> next;
    }while(temp != Last->next);
    cout<<"\n";
}
template <class T>
int SinglyCL<T>::Count()
{
    struct nodeS<T>* temp = First;

    int iCnt = 0;
    do
    {
        iCnt++;
        temp = temp -> next;
    }while(temp != Last->next);
    return iCnt;
}
template <class T>
void SinglyCL<T>::DeleteFirst()
{
    struct nodeS<T>* temp = First;

    if((First == NULL) && (Last == NULL)) 
    {
        return;
    }
    else if(First == Last)   
    {
        delete First;
        First = NULL;
        Last = NULL;
    }
    else    
    {
        First = (First)->next;
        delete temp;

        (Last) ->next = First;
    }
}

template <class T>
void SinglyCL<T>::DeleteLast()
{
    struct nodeS<T>* temp = First;

    if((First == NULL) && (Last == NULL)) 
    {
        return;
    }
    else if(First == Last)   
    { 
        delete First;

        First = NULL;
        Last = NULL;
    }
    else   
    {
        while(temp->next != (Last))
        {
            temp = temp -> next;
        }

        delete temp->next;

        Last = temp; 
        (Last) ->next = First;
    }
}
template <class T>
void SinglyCL<T>::InsertAtPos(T no, int ipos)
{
    int iNodeCnt = 0, iCnt = 0;
    iNodeCnt = Count();
    struct nodeS<T>* newn = NULL;
    struct nodeS<T>* temp = First;

    if((ipos < 1) || (ipos > iNodeCnt + 1))
    {
        cout<<"Invalid position"<<"\n";
        return;
    }

    if(ipos == 1)
    {
        InsertFirst(no);
    }
    else if(ipos == iNodeCnt+1)
    {
        InsertLast(no);
    }
    else
    {
        newn = new struct nodeS<T>;

        newn->data = no;
        newn->next = NULL;

        for(iCnt = 1; iCnt < ipos-1; iCnt++)
        {
            temp = temp->next;
        }

        newn->next = temp->next;
        temp->next = newn;
    }
}
template <class T>
void SinglyCL<T>::DeleteAtPos(int ipos)
{
    int iNodeCnt = 0, iCnt = 0;
    iNodeCnt = Count();
    struct nodeS<T>* temp1 = First;
    struct nodeS<T>* temp2 = NULL;

    if((ipos < 1) || (ipos > iNodeCnt))
    {
        cout<<"Invalid position"<<"\n";
        return;
    }

    if(ipos == 1)
    {
        DeleteFirst();
    }
    else if(ipos == iNodeCnt)
    {
        DeleteLast();
    }
    else
    {
        for(iCnt = 1; iCnt < ipos-1; iCnt++)
        {
            temp1 = temp1->next;
        }   
        temp2 = temp1 ->next;

        temp1->next = temp2->next;
        delete temp2;
    }
}

////////////////////////////////////////////////////////////////

// Class of Doubly Linear Linked List

template <class T>
class DoublyLL
{
    public:
        struct nodeD<T> * First;
        int iCount; 
        DoublyLL();

        void InsertFirst(T no);
        void InsertLast(T no);
        void InsertAtPos(T no, int iPos);

        void DeleteFirst();
        void DeleteLast();
        void DeleteAtPos(int iPos);

        void Display();
        //int Count();
};

template <class T>
DoublyLL<T> :: DoublyLL()
{
    First = NULL;
    iCount = 0;
}

template <class T>
void DoublyLL<T> :: InsertFirst(T no)
{
    struct nodeD<T> * newn = new struct nodeD<T>;  

    newn -> data = no;
    newn->next = NULL;
    newn->next = NULL;

    if(First == NULL)
    {
        First = newn;
        iCount++;
    }
    else
    {
        newn->next = First;
        First->prev = newn;
        First = newn;
        iCount++;
    }
}

template<class T>
void DoublyLL<T>:: InsertLast(T no)
{

    struct nodeD<T>* newn = new struct nodeD<T>;

    newn->data = no;
    newn->next =  NULL;
    newn->prev = NULL;

    if(First == NULL)   
    {
        First = newn;
        newn->prev = First;
        iCount++;
    }
    else   
    {
        struct nodeD<T>* temp = First;

        while(temp->next != NULL)
        {
            temp = temp -> next;
        }
        temp->next = newn;
        newn->prev = temp;
        iCount++;
    }
}
template<class T>
void DoublyLL<T> :: InsertAtPos(T no, int ipos)
{

    if((ipos < 1) || (ipos > iCount+1))
    {
        cout<<"Invalid position"<<"\n";
        return;
    }

    if(ipos == 1)
    {
        InsertFirst(no);
    }
    else if(ipos == iCount + 1)
    {
        InsertLast(no);
    }
    else
    {
        struct nodeD<T>* newn = new struct nodeD<T>;

        newn->data = no;
        newn->next = NULL;
        newn->prev = NULL;

        struct nodeD <T>* temp = First;
        for(int iCnt = 1; iCnt < ipos-1; iCnt++)
        {
            temp = temp->next;
        }

        newn->next = temp->next;
        temp->next->prev = newn;
        temp->next = newn;
        newn->prev = temp;
        iCount++;

    }
}
template<class T>
void DoublyLL<T> ::DeleteFirst()
{
    if (First == NULL) 
    {
        return;
    }
    else if (First->next == NULL) 
    {
        delete First;
        First = NULL;
        First->prev = NULL;
        iCount--;
    }
    else
    {
        struct nodeD<T>* temp = First;
        First = First->next;
        First->prev = NULL;
        delete temp;
        iCount--;
    }
}
template<class T>
void DoublyLL<T>:: DeleteLast()
{    
    if(First == NULL)  
    {
        return;
    }
    else if(First -> next == NULL) 
    {
        delete First;
        First = NULL;
        First->prev = NULL;
        iCount--;
    }
    else
    {
        struct nodeD<T>* temp = First;

        while(temp->next->next != NULL)
        {
            temp = temp->next;
        }

        delete temp->next;
        temp->next = NULL;
        iCount--;

    }
}
template<class T>
void DoublyLL<T> :: DeleteAtPos(int ipos)
{
    if((ipos < 1) || (ipos > iCount))
    {
        cout<<"Invalid position"<<"\n";
        return;
    }

    if(ipos == 1)
    {
        DeleteFirst();
    }
    else if(ipos == iCount)
    {
        DeleteLast();
    }
    else
    {
        struct nodeD<T>* temp1 = First;

        for(int iCnt = 1; iCnt < ipos-1; iCnt++)
        {
            temp1 = temp1->next;
        }

        struct nodeD<T>* temp2 = temp1->next;

        temp1->next = temp2->next;
        temp2->next->prev = temp1;
        delete temp2;

        iCount--;
    }
}

template <class T>
void DoublyLL<T> :: Display()
{
    struct nodeD<T> * temp = First;

    while(temp != NULL)
    {
        cout<<"| "<<temp->data<<" |->";
        temp = temp -> next;
    }
    cout<<"\n";
}

// template <class T>
// int DoublyLL<T> :: Count()
// {
//     struct nodeD<T> *  temp = First;
//     int iCnt = 0;

//     while(temp != NULL)
//     {
//         iCnt++;
//         temp = temp -> next;
//     }
//     return iCnt;
// }

////////////////////////////////////////////////////////////////

// // Class of Doubly Circular Linked List

template <class T>
class DoublyCL
{
    public:
        struct nodeD<T> * First;
        struct nodeD<T> * Last;

        DoublyCL();
        
        void InsertFirst(T no);
        void InsertLast(T no);
        void InsertAtPos(T no, int iPos);

        void DeleteFirst();
        void DeleteLast();
        void DeleteAtPos(int iPos);

        void Display();
        int Count();
};

template <class T>
DoublyCL<T> :: DoublyCL() 
{
    First = NULL;
    Last = NULL;
}
template <class T>
void DoublyCL<T> :: InsertFirst(T no)
{
    struct nodeD<T>* newn = new struct nodeD<T>; 

    newn->data = no;
    newn->next = NULL;
    newn -> prev = NULL;

    if((First == NULL) && (Last == NULL)) 
    {
        First = newn;
        Last = newn;
    }
    else   
    {
        newn->next = First;
        (First)->prev = newn;
        First = newn; 
    }

    (First)->prev = Last;
    (Last)->next = First;
}

template <class T>
void DoublyCL<T> :: InsertLast(T no)
{
    struct nodeD<T>* newn = new struct nodeD<T>; 

    newn->data = no;
    newn->next = NULL;
    newn -> prev = NULL;

    if((First == NULL) && (Last == NULL)) 
    {
        First = newn;
        Last = newn;
    }
    else   
    {
        (Last) -> next = newn;
        newn->prev = Last;
        Last = newn;
    }

    (First)->prev = Last;
    (Last)->next = First;
}

template <class T>
void DoublyCL <T> :: Display()
{
    struct nodeD<T>* temp = First;

    if(First == NULL && Last == NULL)
    {
        cout<<"Linked list is empty"<<"\n";
        return;
    }

    cout<<"Elements of Linked list are : "<<"\n";
    do
    {
        cout<<"| " <<temp->data<<"|<=> ";
        temp = temp -> next;
    }while(temp != Last->next);

    cout<<"\n";
}

template <class T>
int DoublyCL <T>:: Count()
{
    int iCnt = 0;
    struct nodeD<T>* temp = First;

    if(First == NULL && Last == NULL)
    {
        return iCnt;
    }

    do
    {
        iCnt++;
        temp = temp -> next;
    }while(temp != Last->next);

    return iCnt;
}
template <class T>
void DoublyCL<T> :: DeleteFirst()
{
    if(First == NULL && Last == NULL) 
    {
        return;
    }
    else if(First == Last)  
    {
        delete First;
        First = NULL;
        Last= NULL;
    }
    else  
    {
        (First) = (First) ->next;
        delete (Last)->next;        

        (First)->prev = Last;
        (Last)->next = First;
    }
}
template <class T>
void DoublyCL<T> :: DeleteLast()
{
    if(First == NULL && Last == NULL)
    {
        return;
    }
    else if(First == Last)    
    {
        delete First;
        First = NULL;
        Last= NULL;
    }
    else   
    {
        Last = (Last) -> prev;
        delete (First)->prev;      

        (First)->prev = Last;
        (Last)->next = First;
    }
}
template <class T>
void DoublyCL <T>:: InsertAtPos(T no, int ipos)
{
    int iNodeCnt = Count();
    struct nodeD<T>* newn = NULL;
    struct nodeD<T>* temp = NULL;
    int iCnt = 0;

    if((ipos < 1) || (ipos > iNodeCnt+1))
    {
        cout<<"Invalid position"<<"\n";
        return;
    }

    if(ipos ==1)
    {
        InsertFirst(no);
    }
    else if(ipos == iNodeCnt+1)
    {
        InsertLast(no);
    }
    else
    {
        newn = new struct nodeD<T>;
        newn->data = no;
        newn->next = NULL;
        newn->prev = NULL;

        temp = First;
        for(iCnt = 1; iCnt < ipos-1; iCnt++)
        {
            temp = temp->next;
        }

        newn->next = temp->next;
        temp->next->prev = newn;

        temp->next = newn;
        newn->prev = temp;
    }
}
template <class T>
void DoublyCL <T>:: DeleteAtPos(int ipos)
{
    int iNodeCnt = Count();
    struct nodeD <T>* temp = NULL;
    int iCnt = 0;

    if((ipos < 1) || (ipos > iNodeCnt))
    {
        cout<<"Invalid position"<<"\n";
        return;
    }

    if(ipos ==1)
    {
        DeleteFirst();
    }
    else if(ipos == iNodeCnt)
    {
        DeleteLast();
    }
    else
    {
        temp = First;
        for(iCnt = 1; iCnt < ipos-1; iCnt++)
        {
            temp = temp->next;
        }

        temp->next = temp->next->next;
        delete temp->next->prev;
        temp->next->prev = temp;
    }
}

/////////////////////////////////////////////////////////////////////////

//class of Stack DataStructure

template <class T>
class Stack
{
    public:
        struct nodeS<T> *First;
        int iCount;

        Stack();

        bool IsStackEmpty();
        void Push(T no);      
        T Pop();              
        void Display();
};

template <class T>
Stack<T> :: Stack()
{
    First = NULL;
    iCount = 0;
}

template <class T>
bool Stack<T> :: IsStackEmpty()
{
    if(iCount == 0)
    {
        return true;
    }
    else
    {
        return false;
    }
}

template <class T>
void Stack<T> :: Push(T no)  
{
    struct nodeS<T> *newn = new nodeS<T>;

    newn->data = no;
    newn->next = NULL;

    if(First == NULL)
    {
        First = newn;
    }
    else
    {
        newn->next = First;
        First = newn;
    }
    
    iCount++;

    cout<<no<<" Gets pushed in the stack succesfully"<<"\n";
}

template <class T>
T Stack<T> :: Pop()         
{
    if(First == NULL)
    {
        cout<<"Unable to pop the element as Stack is empty."<<"\n";
        return -1;
    }
    else 
    {
        T value = First -> data;
        struct nodeS<T> *temp = First;

        First = First ->next;
        delete temp;

        iCount--;

        return value;
    }
}

template <class T>
void Stack<T> :: Display()
{
    if(First == NULL)
    {
        cout<<"Stack is empty."<<"\n";
    }
    else 
    {
        cout<<"Elements of stack are : "<<"\n";

        struct nodeS<T> *temp = First;
        while(temp != NULL)
        {
            cout<<"| "<<temp->data<<" |-> ";
            temp = temp -> next;
        }
        cout<<" NULL"<<"\n";
    }
}

/// //////////////////////////////////////////////////////////////////////////
// class of Queue Data structure

template<class T>
class Queue
{
    public:
        struct nodeS <T>*First;
        int iCount;

        Queue();

        bool IsQueueEmpty();
        void EnQueue(T no);     
        T DeQueue();              
        void Display();
};
template<class T>
Queue<T> :: Queue()
{
    First = NULL;
    iCount = 0;
}
template<class T>
bool Queue <T>:: IsQueueEmpty()
{
    if(iCount == 0)
    {
        return true;
    }
    else
    {
        return false;
    }
}
template<class T>
void Queue <T>:: EnQueue(T no)  
{
    struct nodeS <T>*newn = new nodeS<T>;

    newn->data = no;
    newn->next = NULL;

    if(First == NULL)
    {
        First = newn;
    }
    else
    {
        struct nodeS <T>*temp = First;

        while(temp->next != NULL)
        {
           temp = temp ->next; 
        }

        temp->next = newn;
    }
    
    iCount++;

    cout<<no<<" Gets pushed in the Queue succesfully"<<"\n";
}
template<class T>
T Queue<T> :: DeQueue()         
{
    if(First == NULL)
    {
        cout<<"Unable to remove the element as Queue is empty."<<"\n";
        return (T)-1;
    }
    else 
    {
        int value = First -> data;
        struct nodeS <T>*temp = First;

        First = First ->next;
        delete temp;

        iCount--;

        return value;
    }
}
template<class T>
void Queue<T> :: Display()
{
    if(First == NULL)
    {
        cout<<"Queue is empty."<<"\n";
    }
    else 
    {
        cout<<"Elements of Queue are : "<<"\n";

        struct nodeS<T> *temp = First;
        while(temp != NULL)
        {
            cout<<"| "<<temp->data<<" |-> ";
            temp = temp -> next;
        }
        cout<<" NULL"<<"\n";
    }
}
/////////////////////////////////////////////////////////////////////////

int main()
{
    
    return 0;
}